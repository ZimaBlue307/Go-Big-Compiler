#! /bin/bash
cd ./go
sh compile.sh /home/superemehornor/桌面/pythonProject/test/test.sh