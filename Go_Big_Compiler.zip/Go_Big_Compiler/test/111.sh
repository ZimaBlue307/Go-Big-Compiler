#! /bin/bash
cd ./go
sh compile.sh test/test1.go