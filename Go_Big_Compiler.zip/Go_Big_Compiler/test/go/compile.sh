#!/bin/bash
#alias grun='java org.antlr.v4.runtime.misc.TestRig'
alias grun='java org.antlr.v4.gui.TestRig'
grun Golang sourceFile -ps "result/$(basename "$1" .go).ps" $1
echo '语法分析树生成完毕~'
bin/irgen $1
if [ -f temporary.ir ]
then
     echo '三地址码生成完毕~'
     cp "temporary.ir" "result/$(basename "$1" .go).ir" 
     bin/codegen temporary.ir > temporary.s
     if [ -f temporary.s ]
     then
          mv "temporary.s" "result/$(basename "$1" .go).s"
          echo '汇编码生成完毕~'
          rm temp.txt temporary.ir
          go build $1
          if [ -f $(basename "$1" .go) ]
          then
               echo '可执行文件运行完毕~'
               ./"$(basename "$1" .go)" > "result/$(basename "$1" .go)_result.txt"
               mv "./$(basename "$1" .go)" result/
               evince "result/$(basename "$1" .go).ps"
               gedit "result/$(basename "$1" .go).ir" "result/$(basename "$1" .go).s" "result/$(basename          "$1" .go)_result.txt"
          else
               echo "可执行文件生成遇到问题..错误原因如终端所示"
          fi
     else
          echo "汇编码生成遇到问题..错误原因如终端所示"
     fi
else
     echo "三地址码生成遇到问题..错误原因如终端所示"
fi
