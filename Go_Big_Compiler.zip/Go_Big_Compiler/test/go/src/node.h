#include<bits/stdc++.h>
using namespace std;

typedef struct{
	char *value;
} node;
//struct node;

