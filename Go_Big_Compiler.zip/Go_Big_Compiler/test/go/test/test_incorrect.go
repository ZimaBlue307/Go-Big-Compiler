package main;
import "new";
var global int;

func foo2(){
	
	var i int;
	a++;
};
func main() {
	
	var a int;
	const a int;	//working for now
	var global int;
	//a = 5;
	foo();
	if(a<6){
		var d string = "he";
	};
	var d *int;
	var d int ;
	d += 5;
}
